# 1. 合并训练和测试数据
X_train <- read.table("UCI HAR Dataset/train/X_train.txt")
y_train <- read.table("UCI HAR Dataset/train/y_train.txt")
subject_train <- read.table("UCI HAR Dataset/train/subject_train.txt")

X_test <- read.table("UCI HAR Dataset/test/X_test.txt")
y_test <- read.table("UCI HAR Dataset/test/y_test.txt")
subject_test <- read.table("UCI HAR Dataset/test/subject_test.txt")

# 合并数据集
X <- rbind(X_train, X_test)
y <- rbind(y_train, y_test)
subject <- rbind(subject_train, subject_test)

# 2. 提取均值和标准差
features <- read.table("UCI HAR Dataset/features.txt")
mean_std_indices <- grep("mean\\(\\)|std\\(\\)", features$V2)
X <- X[, mean_std_indices]
colnames(X) <- features$V2[mean_std_indices]

# 3. 使用描述性活动名称
activity_labels <- read.table("UCI HAR Dataset/activity_labels.txt")
y[, 1] <- activity_labels[y[, 1], 2]
colnames(y) <- "Activity"

# 4. 给数据集添加变量名
colnames(subject) <- "Subject"

# 合并所有数据
tidy_data <- cbind(subject, y, X)

# 5. 创建独立数据集
library(dplyr)
final_data <- tidy_data %>%
  group_by(Subject, Activity) %>%
  summarise_all(mean)

# 输出到文件
write.table(final_data, "tidy_data.txt", row.names = FALSE)

