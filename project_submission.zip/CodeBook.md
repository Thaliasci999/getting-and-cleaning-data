# Code Book

## Variables
- `Subject`: The ID of the participant.
- `Activity`: The activity performed (e.g., WALKING, SITTING).
- Other variables: Sensor measurements (mean and standard deviation).

## Steps to Clean Data
1. Merged training and testing datasets.
2. Extracted measurements on mean and standard deviation.
3. Replaced activity IDs with descriptive names.
4. Created a tidy dataset with the average for each variable by activity and subject.
