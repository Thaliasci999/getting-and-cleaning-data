# Getting and Cleaning Data Course Project

This repository contains the solution to the Getting and Cleaning Data Course Project.

## Files
- `run_analysis.R`: R script to clean and analyze the data.
- `tidy_data.txt`: The tidy dataset created by the script.

## Analysis Steps
1. Merged training and testing datasets.
2. Extracted measurements on the mean and standard deviation.
3. Used descriptive activity names.
4. Appropriately labeled the dataset with descriptive variable names.
5. Created a second independent tidy dataset with the average of each variable for each activity and subject.
